package com.wilmanSaragihSitioJPlane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WilmanSaragihSitioJPlaneApplication {

	public static void main(String[] args) {
		SpringApplication.run(WilmanSaragihSitioJPlaneApplication.class, args);
	}

}
